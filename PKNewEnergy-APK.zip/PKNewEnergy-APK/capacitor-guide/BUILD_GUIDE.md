# 📱 วิธีสร้าง P&K New Energy APK
## ใช้ Capacitor (แนวเดียวกับ BYD Solenoid Controller)

---

## ✅ สิ่งที่ต้องติดตั้งก่อน

| โปรแกรม | ดาวน์โหลด | หมายเหตุ |
|---------|-----------|---------|
| Node.js | https://nodejs.org | เลือก LTS |
| Android Studio | https://developer.android.com/studio | ใช้ build APK |
| JDK 17 | มากับ Android Studio | ไม่ต้องติดตั้งแยก |

---

## 📁 โครงสร้างโฟลเดอร์ที่ได้รับ

```
PKNewEnergy-APK/
├── capacitor.config.json       ← config หลัก
├── package.json                ← dependencies
└── src/main/assets/www/
    └── index.html              ← ไฟล์แอปทั้งหมด
```

---

## 🔨 ขั้นตอนสร้าง APK

### ขั้นที่ 1 — เปิด Terminal ใน folder PKNewEnergy-APK

```bash
cd D:\Drive E\EV Garage\PKNewEnergy\PKNewEnergy-APK
```

### ขั้นที่ 2 — ติดตั้ง Capacitor

```bash
npm install
```

### ขั้นที่ 3 — เพิ่ม Android platform

```bash
npx cap add android
```

> ถ้าเคยทำแล้วมีโฟลเดอร์ android อยู่แล้ว ข้ามขั้นนี้

### ขั้นที่ 4 — Sync ไฟล์ HTML เข้า Android project

```bash
npx cap sync android
```

> **ทำทุกครั้ง** ที่อัปเดต index.html

### ขั้นที่ 5 — เปิด Android Studio

```bash
npx cap open android
```

### ขั้นที่ 6 — Build APK ใน Android Studio

1. เมนู **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. รอ build เสร็จ (ครั้งแรกนานหน่อย ~5-10 นาที)
3. คลิก **"locate"** ใน popup → จะเจอไฟล์ `.apk`

APK จะอยู่ที่:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

### ขั้นที่ 7 — ติดตั้งบนมือถือ

1. Copy `app-debug.apk` ไปมือถือ
2. เปิดไฟล์ → ติดตั้ง (ต้องเปิด "Unknown sources" ก่อน)
3. หรือ drag ไปที่ emulator ใน Android Studio

---

## ⚙️ การตั้งค่าหลังติดตั้ง

เปิดแอป → ไปหน้า **ตั้งค่า** → ใส่ GAS URL เหมือนบน PC

---

## 🔄 อัปเดตแอปในอนาคต

เมื่อแก้ไข index.html ใหม่:

```bash
# 1. copy index.html ใหม่ไปที่ src/main/assets/www/
# 2. รัน sync
npx cap sync android
# 3. build APK ใหม่ใน Android Studio
```

---

## 🐛 แก้ปัญหาที่พบบ่อย

| ปัญหา | วิธีแก้ |
|-------|---------|
| เรียก GAS ไม่ได้ | ตรวจสอบ network_security_config.xml ถูก apply หรือเปล่า |
| แอปค้างหน้าขาว | ดู Logcat ใน Android Studio หา error |
| font แสดงผิด | ตรวจสอบ internet connection (font โหลดจาก Google) |
| localStorage ไม่ sync | ปกติ — ข้อมูล sync ผ่าน GAS เท่านั้น |

---

## 📝 หมายเหตุสำคัญ

- APK นี้เป็น **debug build** — ใช้งานภายในองค์กรได้เลย ไม่ต้อง Play Store
- ข้อมูลทุกอย่าง sync ผ่าน Google Sheets เหมือน PC ทุกประการ
- session login เก็บใน localStorage ของ WebView (แต่ละเครื่องแยกกัน)
- ถ้าต้องการ **release build** (ไม่มี debug watermark) แจ้งได้ครับ
